package com.adesh.googleguice;

public interface Greeter {
	void greet();
}
